
  # Admin dashboard for medication app

  This is a code bundle for Admin dashboard for medication app. The original project is available at https://www.figma.com/design/nkXbG9NjDcSg7fwRRugK6e/Admin-dashboard-for-medication-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  