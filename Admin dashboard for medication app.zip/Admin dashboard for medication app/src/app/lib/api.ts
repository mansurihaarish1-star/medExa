export async function getPatients() {
  const response = await fetch("http://localhost:5000/patients");
  return await response.json();
}