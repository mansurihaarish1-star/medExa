import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { TrendingUp, TrendingDown, Users, Pill, CheckCircle2, XCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useState } from "react";

const complianceByPatient = [
  { name: "John Doe", completed: 85, missed: 15 },
  { name: "Jane Smith", completed: 92, missed: 8 },
  { name: "Mike Johnson", completed: 78, missed: 22 },
  { name: "Sarah Williams", completed: 95, missed: 5 },
  { name: "Robert Brown", completed: 88, missed: 12 },
];

const monthlyTrend = [
  { month: "Jan", patients: 980, alarms: 2850, compliance: 82 },
  { month: "Feb", patients: 1050, alarms: 3100, compliance: 85 },
  { month: "Mar", patients: 1120, alarms: 3280, compliance: 83 },
  { month: "Apr", patients: 1180, alarms: 3450, compliance: 86 },
  { month: "May", patients: 1200, alarms: 3520, compliance: 88 },
  { month: "Jun", patients: 1234, alarms: 3600, compliance: 87 },
];

const medicineUsage = [
  { name: "Aspirin", count: 245 },
  { name: "Metformin", count: 198 },
  { name: "Lisinopril", count: 176 },
  { name: "Atorvastatin", count: 165 },
  { name: "Amlodipine", count: 142 },
  { name: "Omeprazole", count: 128 },
  { name: "Levothyroxine", count: 115 },
  { name: "Others", count: 422 },
];

const taskCompletionRates = [
  { name: "Math Quiz", value: 88, color: "#3b82f6" },
  { name: "Memory Game", value: 92, color: "#10b981" },
  { name: "Word Puzzle", value: 85, color: "#f59e0b" },
  { name: "Barcode Scan", value: 95, color: "#8b5cf6" },
  { name: "Photo Verify", value: 78, color: "#ec4899" },
];

const hourlyAlarmDistribution = [
  { hour: "6 AM", count: 145 },
  { hour: "8 AM", count: 320 },
  { hour: "10 AM", count: 210 },
  { hour: "12 PM", count: 285 },
  { hour: "2 PM", count: 190 },
  { hour: "6 PM", count: 310 },
  { hour: "8 PM", count: 245 },
  { hour: "10 PM", count: 180 },
];

export function Analytics() {
  const [timeRange, setTimeRange] = useState("month");

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Analytics</h1>
          <p className="text-gray-500 mt-1">Insights and performance metrics</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Select time range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">Last 7 Days</SelectItem>
            <SelectItem value="month">Last Month</SelectItem>
            <SelectItem value="quarter">Last Quarter</SelectItem>
            <SelectItem value="year">Last Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Avg. Compliance Rate</p>
                <p className="text-2xl font-semibold mt-1">87%</p>
                <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  +5% from last month
                </p>
              </div>
              <CheckCircle2 className="h-12 w-12 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Users</p>
                <p className="text-2xl font-semibold mt-1">1,234</p>
                <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  +12% growth
                </p>
              </div>
              <Users className="h-12 w-12 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Daily Alarms</p>
                <p className="text-2xl font-semibold mt-1">3,600</p>
                <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                  <TrendingUp className="h-4 w-4" />
                  +8% increase
                </p>
              </div>
              <Pill className="h-12 w-12 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Missed Rate</p>
                <p className="text-2xl font-semibold mt-1">13%</p>
                <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                  <TrendingDown className="h-4 w-4" />
                  -3% improvement
                </p>
              </div>
              <XCircle className="h-12 w-12 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Growth Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="patients" stroke="#3b82f6" name="Patients" strokeWidth={2} />
                <Line type="monotone" dataKey="compliance" stroke="#10b981" name="Compliance %" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Compliance Rate by Patient</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={complianceByPatient}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="completed" stackId="a" fill="#10b981" name="Completed %" />
                <Bar dataKey="missed" stackId="a" fill="#ef4444" name="Missed %" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Task Completion Rates</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={taskCompletionRates}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {taskCompletionRates.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Most Prescribed Medicines</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={medicineUsage} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip />
                <Bar dataKey="count" fill="#8b5cf6" name="Prescriptions" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 3 */}
      <Card>
        <CardHeader>
          <CardTitle>Hourly Alarm Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={hourlyAlarmDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#f59e0b" name="Alarms" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Top Performing Patient</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="font-medium text-lg">Sarah Williams</p>
              <p className="text-3xl font-semibold text-green-600">95%</p>
              <p className="text-sm text-gray-500">Compliance Rate</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Most Used Task</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="font-medium text-lg">Barcode Scan</p>
              <p className="text-3xl font-semibold text-blue-600">95%</p>
              <p className="text-sm text-gray-500">Success Rate</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Peak Alarm Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p className="font-medium text-lg">8:00 AM</p>
              <p className="text-3xl font-semibold text-purple-600">320</p>
              <p className="text-sm text-gray-500">Daily Alarms</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
