import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Users, Pill, FileText, AlarmClock, TrendingUp, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";

const statsData = [
  { label: "Total Patients", value: "1,234", change: "+12%", icon: Users, color: "bg-blue-500" },
  { label: "Active Medicines", value: "456", change: "+5%", icon: Pill, color: "bg-green-500" },
  { label: "Prescriptions", value: "2,891", change: "+18%", icon: FileText, color: "bg-purple-500" },
  { label: "Active Alarms", value: "3,421", change: "+8%", icon: AlarmClock, color: "bg-orange-500" },
];

const weeklyData = [
  { day: "Mon", alarms: 450, completed: 380 },
  { day: "Tue", alarms: 520, completed: 420 },
  { day: "Wed", alarms: 490, completed: 410 },
  { day: "Thu", alarms: 580, completed: 520 },
  { day: "Fri", alarms: 510, completed: 460 },
  { day: "Sat", alarms: 420, completed: 380 },
  { day: "Sun", alarms: 390, completed: 350 },
];

const complianceData = [
  { name: "Completed", value: 78, color: "#10b981" },
  { name: "Missed", value: 15, color: "#ef4444" },
  { name: "Pending", value: 7, color: "#f59e0b" },
];

const recentAlerts = [
  { id: 1, patient: "John Doe", medicine: "Aspirin 75mg", status: "missed", time: "2 hours ago" },
  { id: 2, patient: "Jane Smith", medicine: "Metformin 500mg", status: "completed", time: "3 hours ago" },
  { id: 3, patient: "Mike Johnson", medicine: "Lisinopril 10mg", status: "pending", time: "30 minutes ago" },
  { id: 4, patient: "Sarah Williams", medicine: "Atorvastatin 20mg", status: "missed", time: "1 hour ago" },
];

export function Dashboard() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Overview of your medicine alarm system</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsData.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">{stat.label}</p>
                    <p className="text-2xl font-semibold mt-1">{stat.value}</p>
                    <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                      <TrendingUp className="h-4 w-4" />
                      {stat.change} from last month
                    </p>
                  </div>
                  <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Weekly Alarm Activity */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Weekly Alarm Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="alarms" fill="#3b82f6" name="Total Alarms" />
                <Bar dataKey="completed" fill="#10b981" name="Completed" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Compliance Rate */}
        <Card>
          <CardHeader>
            <CardTitle>Compliance Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={complianceData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {complianceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Alerts */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentAlerts.map((alert) => (
              <div key={alert.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full ${
                    alert.status === 'completed' ? 'bg-green-500' : 
                    alert.status === 'missed' ? 'bg-red-500' : 'bg-orange-500'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900">{alert.patient}</p>
                    <p className="text-sm text-gray-500">{alert.medicine}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    alert.status === 'completed' ? 'bg-green-100 text-green-800' : 
                    alert.status === 'missed' ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800'
                  }`}>
                    {alert.status}
                  </span>
                  <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
