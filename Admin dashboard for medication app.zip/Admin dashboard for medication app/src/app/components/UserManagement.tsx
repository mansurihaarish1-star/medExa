import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Plus, Search, Edit, Trash2, Mail, Phone } from "lucide-react";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  age: number;
  gender: string;
  status: "active" | "inactive";
  activePrescriptions: number;
  activeAlarms: number;
}

interface Doctor {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string;
  licenseNumber: string;
  status: "active" | "inactive";
  totalPrescriptions: number;
}

const mockPatients: Patient[] = [
  {
    id: "1",
    name: "John Doe",
    email: "john.doe@email.com",
    phone: "+1 234-567-8901",
    age: 45,
    gender: "Male",
    status: "active",
    activePrescriptions: 3,
    activeAlarms: 8,
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane.smith@email.com",
    phone: "+1 234-567-8902",
    age: 52,
    gender: "Female",
    status: "active",
    activePrescriptions: 5,
    activeAlarms: 12,
  },
  {
    id: "3",
    name: "Mike Johnson",
    email: "mike.j@email.com",
    phone: "+1 234-567-8903",
    age: 38,
    gender: "Male",
    status: "active",
    activePrescriptions: 2,
    activeAlarms: 6,
  },
];

const mockDoctors: Doctor[] = [
  {
    id: "1",
    name: "Dr. Sarah Williams",
    email: "dr.sarah@clinic.com",
    phone: "+1 234-567-9001",
    specialization: "Cardiologist",
    licenseNumber: "MD-12345",
    status: "active",
    totalPrescriptions: 245,
  },
  {
    id: "2",
    name: "Dr. Robert Brown",
    email: "dr.robert@clinic.com",
    phone: "+1 234-567-9002",
    specialization: "General Physician",
    licenseNumber: "MD-12346",
    status: "active",
    totalPrescriptions: 389,
  },
  {
    id: "3",
    name: "Dr. Emily Davis",
    email: "dr.emily@clinic.com",
    phone: "+1 234-567-9003",
    specialization: "Endocrinologist",
    licenseNumber: "MD-12347",
    status: "active",
    totalPrescriptions: 198,
  },
];

export function UserManagement() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>(mockDoctors);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddPatientDialogOpen, setIsAddPatientDialogOpen] = useState(false);
  const [isAddDoctorDialogOpen, setIsAddDoctorDialogOpen] = useState(false);
  const [patientFormData, setPatientFormData] = useState<Partial<Patient>>({});
  const [doctorFormData, setDoctorFormData] = useState<Partial<Doctor>>({});

  // 🔵 Load patients from backend
  useEffect(() => {
    fetch("http://localhost:5000/patients")
      .then((res) => res.json())
      .then((data) => {
        const formatted = data.map((p: any) => ({
          id: String(p.id),
          name: p.name,
          email: p.email || "N/A",
          phone: p.phone || "N/A",
          age: p.age || 0,
          gender: p.gender || "Unknown",
          status: "active",
          activePrescriptions: 0,
          activeAlarms: 0,
        }));

        setPatients(formatted);
      })
      .catch((err) => console.error("Error fetching patients:", err));
  }, []);

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    patient.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredDoctors = doctors.filter(doctor =>
    doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doctor.specialization.toLowerCase().includes(searchQuery.toLowerCase())
  );

const handleAddPatient = async () => {
  try {
    const response = await fetch("http://localhost:5000/patients", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name: patientFormData.name,
        email: patientFormData.email,
        phone: patientFormData.phone,
        age: patientFormData.age,
        gender: patientFormData.gender
      })
    });

    const data = await response.json();

    console.log("Patient inserted:", data);

    const res = await fetch("http://localhost:5000/patients");
    const patients = await res.json();

    setPatients(patients);

    setIsAddPatientDialogOpen(false);
    setPatientFormData({});
  } catch (error) {
    console.error("Insert error:", error);
  }
};

 
 
  const handleAddDoctor = () => {
    const newDoctor: Doctor = {
      id: String(doctors.length + 1),
      name: doctorFormData.name || "",
      email: doctorFormData.email || "",
      phone: doctorFormData.phone || "",
      specialization: doctorFormData.specialization || "",
      licenseNumber: doctorFormData.licenseNumber || "",
      status: "active",
      totalPrescriptions: 0,
    };
    setDoctors([...doctors, newDoctor]);
    setIsAddDoctorDialogOpen(false);
    setDoctorFormData({});
  };

 const handleDeletePatient = async (id: string) => {
  try {
    await fetch(`http://localhost:5000/patients/${id}`, {
      method: "DELETE",
    });

    setPatients(patients.filter((p) => p.id !== id));
  } catch (error) {
    console.error("Error deleting patient:", error);
  }
};

  const handleDeleteDoctor = (id: string) => {
    setDoctors(doctors.filter(d => d.id !== id));
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">User Management</h1>
        <p className="text-gray-500 mt-1">Manage patients and doctors</p>
      </div>

      <Tabs defaultValue="patients" className="space-y-6">
        <TabsList>
          <TabsTrigger value="patients">Patients</TabsTrigger>
          <TabsTrigger value="doctors">Doctors</TabsTrigger>
        </TabsList>

        <TabsContent value="patients">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search patients..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Dialog open={isAddPatientDialogOpen} onOpenChange={setIsAddPatientDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      Add Patient
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Patient</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div>
                        <Label htmlFor="patientName">Full Name</Label>
                        <Input
                          id="patientName"
                          value={patientFormData.name || ""}
                          onChange={(e) => setPatientFormData({ ...patientFormData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="patientEmail">Email</Label>
                        <Input
                          id="patientEmail"
                          type="email"
                          value={patientFormData.email || ""}
                          onChange={(e) => setPatientFormData({ ...patientFormData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="patientPhone">Phone</Label>
                        <Input
                          id="patientPhone"
                          value={patientFormData.phone || ""}
                          onChange={(e) => setPatientFormData({ ...patientFormData, phone: e.target.value })}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="patientAge">Age</Label>
                          <Input
                            id="patientAge"
                            type="number"
                            value={patientFormData.age || ""}
                            onChange={(e) => setPatientFormData({ ...patientFormData, age: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="patientGender">Gender</Label>
                          <Select
                            value={patientFormData.gender}
                            onValueChange={(value) => setPatientFormData({ ...patientFormData, gender: value })}
                          >
                            <SelectTrigger id="patientGender">
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Male">Male</SelectItem>
                              <SelectItem value="Female">Female</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <Button onClick={handleAddPatient} className="w-full">Add Patient</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Age</TableHead>
                    <TableHead>Gender</TableHead>
                    <TableHead>Prescriptions</TableHead>
                    <TableHead>Alarms</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPatients.map((patient) => (
                    <TableRow key={patient.id}>
                      <TableCell className="font-medium">{patient.name}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div className="flex items-center gap-1">
                            <Mail className="h-3 w-3" />
                            {patient.email}
                          </div>
                          <div className="flex items-center gap-1 text-gray-500">
                            <Phone className="h-3 w-3" />
                            {patient.phone}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{patient.age}</TableCell>
                      <TableCell>{patient.gender}</TableCell>
                      <TableCell>{patient.activePrescriptions}</TableCell>
                      <TableCell>{patient.activeAlarms}</TableCell>
                      <TableCell>
                        <Badge variant={patient.status === "active" ? "default" : "secondary"}>
                          {patient.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeletePatient(patient.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="doctors">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search doctors..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                <Dialog open={isAddDoctorDialogOpen} onOpenChange={setIsAddDoctorDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="flex items-center gap-2">
                      <Plus className="h-4 w-4" />
                      Add Doctor
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Doctor</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4 mt-4">
                      <div>
                        <Label htmlFor="doctorName">Full Name</Label>
                        <Input
                          id="doctorName"
                          value={doctorFormData.name || ""}
                          onChange={(e) => setDoctorFormData({ ...doctorFormData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="doctorEmail">Email</Label>
                        <Input
                          id="doctorEmail"
                          type="email"
                          value={doctorFormData.email || ""}
                          onChange={(e) => setDoctorFormData({ ...doctorFormData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="doctorPhone">Phone</Label>
                        <Input
                          id="doctorPhone"
                          value={doctorFormData.phone || ""}
                          onChange={(e) => setDoctorFormData({ ...doctorFormData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="specialization">Specialization</Label>
                        <Input
                          id="specialization"
                          value={doctorFormData.specialization || ""}
                          onChange={(e) => setDoctorFormData({ ...doctorFormData, specialization: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="licenseNumber">License Number</Label>
                        <Input
                          id="licenseNumber"
                          value={doctorFormData.licenseNumber || ""}
                          onChange={(e) => setDoctorFormData({ ...doctorFormData, licenseNumber: e.target.value })}
                        />
                      </div>
                      <Button onClick={handleAddDoctor} className="w-full">Add Doctor</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Specialization</TableHead>
                    <TableHead>License No.</TableHead>
                    <TableHead>Prescriptions</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredDoctors.map((doctor) => (
                    <TableRow key={doctor.id}>
                      <TableCell className="font-medium">{doctor.name}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div className="flex items-center gap-1">
                            <Mail className="h-3 w-3" />
                            {doctor.email}
                          </div>
                          <div className="flex items-center gap-1 text-gray-500">
                            <Phone className="h-3 w-3" />
                            {doctor.phone}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{doctor.specialization}</Badge>
                      </TableCell>
                      <TableCell>{doctor.licenseNumber}</TableCell>
                      <TableCell>{doctor.totalPrescriptions}</TableCell>
                      <TableCell>
                        <Badge variant={doctor.status === "active" ? "default" : "secondary"}>
                          {doctor.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteDoctor(doctor.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
