import { useState } from "react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Search, Eye, Clock, CheckCircle2, XCircle } from "lucide-react";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Switch } from "./ui/switch";

interface Alarm {
  id: string;
  patientName: string;
  medicineName: string;
  dosage: string;
  time: string;
  task: string;
  taskDescription: string;
  status: "pending" | "completed" | "missed";
  isActive: boolean;
  lastTaken?: string;
  nextDue: string;
}

const mockAlarms: Alarm[] = [
  {
    id: "1",
    patientName: "John Doe",
    medicineName: "Aspirin",
    dosage: "75mg",
    time: "08:00 AM",
    task: "Math Quiz",
    taskDescription: "Solve 5 simple math problems",
    status: "completed",
    isActive: true,
    lastTaken: "2026-02-16 08:05 AM",
    nextDue: "2026-02-17 08:00 AM",
  },
  {
    id: "2",
    patientName: "John Doe",
    medicineName: "Metformin",
    dosage: "500mg",
    time: "12:00 PM",
    task: "Memory Game",
    taskDescription: "Complete pattern matching game",
    status: "pending",
    isActive: true,
    nextDue: "2026-02-16 12:00 PM",
  },
  {
    id: "3",
    patientName: "Jane Smith",
    medicineName: "Lisinopril",
    dosage: "10mg",
    time: "09:00 AM",
    task: "Word Puzzle",
    taskDescription: "Find 10 words in word search",
    status: "missed",
    isActive: true,
    nextDue: "2026-02-17 09:00 AM",
  },
  {
    id: "4",
    patientName: "Jane Smith",
    medicineName: "Atorvastatin",
    dosage: "20mg",
    time: "10:00 PM",
    task: "Quick Quiz",
    taskDescription: "Answer 3 health-related questions",
    status: "pending",
    isActive: true,
    nextDue: "2026-02-16 10:00 PM",
  },
  {
    id: "5",
    patientName: "Mike Johnson",
    medicineName: "Metformin",
    dosage: "850mg",
    time: "07:30 AM",
    task: "Barcode Scan",
    taskDescription: "Scan medicine barcode to confirm",
    status: "completed",
    isActive: true,
    lastTaken: "2026-02-16 07:35 AM",
    nextDue: "2026-02-17 07:30 AM",
  },
];

const availableTasks = [
  { value: "math-quiz", label: "Math Quiz", description: "Solve simple math problems" },
  { value: "memory-game", label: "Memory Game", description: "Complete pattern matching" },
  { value: "word-puzzle", label: "Word Puzzle", description: "Find words in word search" },
  { value: "barcode-scan", label: "Barcode Scan", description: "Scan medicine barcode" },
  { value: "photo-verify", label: "Photo Verification", description: "Take a photo of medicine" },
  { value: "shake-phone", label: "Shake Phone", description: "Shake phone 20 times" },
  { value: "walk-steps", label: "Walk Steps", description: "Take 50 steps" },
];

export function AlarmManagement() {
  const [alarms, setAlarms] = useState<Alarm[]>(mockAlarms);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAlarm, setSelectedAlarm] = useState<Alarm | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filteredAlarms = alarms.filter(alarm => {
    const matchesSearch = alarm.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      alarm.medicineName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === "all" || alarm.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleViewAlarm = (alarm: Alarm) => {
    setSelectedAlarm(alarm);
    setIsViewDialogOpen(true);
  };

  const handleToggleActive = (id: string) => {
    setAlarms(alarms.map(alarm =>
      alarm.id === id ? { ...alarm, isActive: !alarm.isActive } : alarm
    ));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case "missed":
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-orange-500" />;
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Alarm & Task Management</h1>
        <p className="text-gray-500 mt-1">Monitor and manage medicine alarms with task requirements</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Alarms</p>
                <p className="text-2xl font-semibold mt-1">{alarms.length}</p>
              </div>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Pending</p>
                <p className="text-2xl font-semibold mt-1">
                  {alarms.filter(a => a.status === "pending").length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Completed</p>
                <p className="text-2xl font-semibold mt-1">
                  {alarms.filter(a => a.status === "completed").length}
                </p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Missed</p>
                <p className="text-2xl font-semibold mt-1">
                  {alarms.filter(a => a.status === "missed").length}
                </p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by patient or medicine..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="missed">Missed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patient</TableHead>
                <TableHead>Medicine</TableHead>
                <TableHead>Time</TableHead>
                <TableHead>Required Task</TableHead>
                <TableHead>Next Due</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Active</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredAlarms.map((alarm) => (
                <TableRow key={alarm.id}>
                  <TableCell className="font-medium">{alarm.patientName}</TableCell>
                  <TableCell>
                    <div>
                      <p>{alarm.medicineName}</p>
                      <p className="text-sm text-gray-500">{alarm.dosage}</p>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3 text-gray-400" />
                      {alarm.time}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{alarm.task}</Badge>
                  </TableCell>
                  <TableCell className="text-sm">{alarm.nextDue}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(alarm.status)}
                      <Badge
                        variant={
                          alarm.status === "completed"
                            ? "default"
                            : alarm.status === "missed"
                            ? "destructive"
                            : "secondary"
                        }
                      >
                        {alarm.status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={alarm.isActive}
                      onCheckedChange={() => handleToggleActive(alarm.id)}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleViewAlarm(alarm)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* View Alarm Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Alarm Details</DialogTitle>
          </DialogHeader>
          {selectedAlarm && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-gray-500">Patient</Label>
                  <p className="font-medium mt-1">{selectedAlarm.patientName}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Status</Label>
                  <div className="flex items-center gap-2 mt-1">
                    {getStatusIcon(selectedAlarm.status)}
                    <Badge
                      variant={
                        selectedAlarm.status === "completed"
                          ? "default"
                          : selectedAlarm.status === "missed"
                          ? "destructive"
                          : "secondary"
                      }
                    >
                      {selectedAlarm.status}
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4">
                <Label className="text-gray-700 mb-2 block">Medicine Information</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-gray-500 text-xs">Name</Label>
                    <p className="font-medium">{selectedAlarm.medicineName}</p>
                  </div>
                  <div>
                    <Label className="text-gray-500 text-xs">Dosage</Label>
                    <p className="font-medium">{selectedAlarm.dosage}</p>
                  </div>
                  <div>
                    <Label className="text-gray-500 text-xs">Scheduled Time</Label>
                    <p className="font-medium">{selectedAlarm.time}</p>
                  </div>
                  <div>
                    <Label className="text-gray-500 text-xs">Next Due</Label>
                    <p className="font-medium">{selectedAlarm.nextDue}</p>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-4 bg-blue-50 border-blue-200">
                <Label className="text-blue-900 mb-2 block">Required Task</Label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-blue-900">{selectedAlarm.task}</p>
                    <Badge variant="outline" className="bg-white">{selectedAlarm.taskDescription}</Badge>
                  </div>
                  <p className="text-sm text-blue-700">
                    ⚠️ Alarm will not stop until the patient completes this task
                  </p>
                </div>
              </div>

              {selectedAlarm.lastTaken && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <Label className="text-green-900 text-sm">Last Taken</Label>
                  <p className="font-medium text-green-900 mt-1">{selectedAlarm.lastTaken}</p>
                </div>
              )}

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <Label>Alarm Active</Label>
                <Switch
                  checked={selectedAlarm.isActive}
                  onCheckedChange={() => handleToggleActive(selectedAlarm.id)}
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
