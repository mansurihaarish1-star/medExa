import { useState } from "react";
import { Card, CardContent, CardHeader } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Plus, Search, Eye, QrCode, Calendar } from "lucide-react";
import { Badge } from "./ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface Prescription {
  id: string;
  prescriptionNumber: string;
  patientName: string;
  doctorName: string;
  date: string;
  status: "active" | "completed" | "cancelled";
  medicines: {
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }[];
  notes: string;
}

const mockPrescriptions: Prescription[] = [
  {
    id: "1",
    prescriptionNumber: "RX-2026-001",
    patientName: "John Doe",
    doctorName: "Dr. Sarah Williams",
    date: "2026-02-10",
    status: "active",
    medicines: [
      { name: "Aspirin", dosage: "75mg", frequency: "Once daily", duration: "30 days" },
      { name: "Metformin", dosage: "500mg", frequency: "Twice daily", duration: "30 days" },
    ],
    notes: "Take with meals. Monitor blood sugar levels daily.",
  },
  {
    id: "2",
    prescriptionNumber: "RX-2026-002",
    patientName: "Jane Smith",
    doctorName: "Dr. Robert Brown",
    date: "2026-02-12",
    status: "active",
    medicines: [
      { name: "Lisinopril", dosage: "10mg", frequency: "Once daily", duration: "60 days" },
      { name: "Atorvastatin", dosage: "20mg", frequency: "Once at bedtime", duration: "60 days" },
    ],
    notes: "Monitor blood pressure weekly. Avoid grapefruit juice.",
  },
  {
    id: "3",
    prescriptionNumber: "RX-2026-003",
    patientName: "Mike Johnson",
    doctorName: "Dr. Emily Davis",
    date: "2026-02-14",
    status: "active",
    medicines: [
      { name: "Metformin", dosage: "850mg", frequency: "Twice daily", duration: "90 days" },
    ],
    notes: "Regular follow-up in 3 months. HbA1c test required.",
  },
];

export function PrescriptionManagement() {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>(mockPrescriptions);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedPrescription, setSelectedPrescription] = useState<Prescription | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isScanDialogOpen, setIsScanDialogOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Prescription>>({
    medicines: [{ name: "", dosage: "", frequency: "", duration: "" }],
  });

  const filteredPrescriptions = prescriptions.filter(prescription =>
    prescription.prescriptionNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    prescription.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    prescription.doctorName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleViewPrescription = (prescription: Prescription) => {
    setSelectedPrescription(prescription);
    setIsViewDialogOpen(true);
  };

  const handleAddMedicine = () => {
    setFormData({
      ...formData,
      medicines: [...(formData.medicines || []), { name: "", dosage: "", frequency: "", duration: "" }],
    });
  };

  const handleRemoveMedicine = (index: number) => {
    const newMedicines = formData.medicines?.filter((_, i) => i !== index);
    setFormData({ ...formData, medicines: newMedicines });
  };

  const handleUpdateMedicine = (index: number, field: string, value: string) => {
    const newMedicines = [...(formData.medicines || [])];
    newMedicines[index] = { ...newMedicines[index], [field]: value };
    setFormData({ ...formData, medicines: newMedicines });
  };

  const handleAddPrescription = () => {
    const newPrescription: Prescription = {
      id: String(prescriptions.length + 1),
      prescriptionNumber: `RX-2026-${String(prescriptions.length + 1).padStart(3, '0')}`,
      patientName: formData.patientName || "",
      doctorName: formData.doctorName || "",
      date: new Date().toISOString().split('T')[0],
      status: "active",
      medicines: formData.medicines || [],
      notes: formData.notes || "",
    };
    setPrescriptions([...prescriptions, newPrescription]);
    setIsAddDialogOpen(false);
    setFormData({ medicines: [{ name: "", dosage: "", frequency: "", duration: "" }] });
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Prescription Management</h1>
          <p className="text-gray-500 mt-1">Manage and track prescriptions</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isScanDialogOpen} onOpenChange={setIsScanDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <QrCode className="h-4 w-4" />
                Scan QR Code
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Scan Prescription QR Code</DialogTitle>
              </DialogHeader>
              <div className="py-8">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center">
                  <QrCode className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-500">QR Scanner would be integrated here</p>
                  <p className="text-sm text-gray-400 mt-2">
                    Patient can scan prescription QR code to automatically import details and set alarms
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                New Prescription
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Prescription</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="patientName">Patient Name</Label>
                    <Input
                      id="patientName"
                      value={formData.patientName || ""}
                      onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="doctorName">Doctor Name</Label>
                    <Input
                      id="doctorName"
                      value={formData.doctorName || ""}
                      onChange={(e) => setFormData({ ...formData, doctorName: e.target.value })}
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <Label>Medicines</Label>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddMedicine}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Medicine
                    </Button>
                  </div>
                  {formData.medicines?.map((medicine, index) => (
                    <div key={index} className="border rounded-lg p-4 mb-3 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Medicine Name</Label>
                          <Input
                            value={medicine.name}
                            onChange={(e) => handleUpdateMedicine(index, "name", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Dosage</Label>
                          <Input
                            value={medicine.dosage}
                            onChange={(e) => handleUpdateMedicine(index, "dosage", e.target.value)}
                            placeholder="e.g., 500mg"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Frequency</Label>
                          <Select
                            value={medicine.frequency}
                            onValueChange={(value) => handleUpdateMedicine(index, "frequency", value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select frequency" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Once daily">Once daily</SelectItem>
                              <SelectItem value="Twice daily">Twice daily</SelectItem>
                              <SelectItem value="Three times daily">Three times daily</SelectItem>
                              <SelectItem value="Four times daily">Four times daily</SelectItem>
                              <SelectItem value="Once at bedtime">Once at bedtime</SelectItem>
                              <SelectItem value="As needed">As needed</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Duration</Label>
                          <Input
                            value={medicine.duration}
                            onChange={(e) => handleUpdateMedicine(index, "duration", e.target.value)}
                            placeholder="e.g., 30 days"
                          />
                        </div>
                      </div>
                      {formData.medicines && formData.medicines.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleRemoveMedicine(index)}
                          className="text-red-500"
                        >
                          Remove Medicine
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                <div>
                  <Label htmlFor="notes">Additional Notes</Label>
                  <Input
                    id="notes"
                    value={formData.notes || ""}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="Special instructions or notes"
                  />
                </div>

                <Button onClick={handleAddPrescription} className="w-full">
                  Create Prescription
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search prescriptions..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Prescription #</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Doctor</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Medicines</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPrescriptions.map((prescription) => (
                <TableRow key={prescription.id}>
                  <TableCell className="font-medium">{prescription.prescriptionNumber}</TableCell>
                  <TableCell>{prescription.patientName}</TableCell>
                  <TableCell>{prescription.doctorName}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3 text-gray-400" />
                      {prescription.date}
                    </div>
                  </TableCell>
                  <TableCell>{prescription.medicines.length} items</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        prescription.status === "active"
                          ? "default"
                          : prescription.status === "completed"
                          ? "secondary"
                          : "destructive"
                      }
                    >
                      {prescription.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleViewPrescription(prescription)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* View Prescription Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Prescription Details</DialogTitle>
          </DialogHeader>
          {selectedPrescription && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <Label className="text-gray-500">Prescription Number</Label>
                  <p className="font-medium mt-1">{selectedPrescription.prescriptionNumber}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Date</Label>
                  <p className="font-medium mt-1">{selectedPrescription.date}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Patient</Label>
                  <p className="font-medium mt-1">{selectedPrescription.patientName}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Doctor</Label>
                  <p className="font-medium mt-1">{selectedPrescription.doctorName}</p>
                </div>
              </div>

              <div>
                <Label className="text-gray-700 mb-3 block">Prescribed Medicines</Label>
                <div className="space-y-3">
                  {selectedPrescription.medicines.map((medicine, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label className="text-gray-500 text-xs">Medicine</Label>
                          <p className="font-medium">{medicine.name}</p>
                        </div>
                        <div>
                          <Label className="text-gray-500 text-xs">Dosage</Label>
                          <p className="font-medium">{medicine.dosage}</p>
                        </div>
                        <div>
                          <Label className="text-gray-500 text-xs">Frequency</Label>
                          <p className="font-medium">{medicine.frequency}</p>
                        </div>
                        <div>
                          <Label className="text-gray-500 text-xs">Duration</Label>
                          <p className="font-medium">{medicine.duration}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedPrescription.notes && (
                <div>
                  <Label className="text-gray-500">Notes</Label>
                  <p className="mt-1 text-sm bg-blue-50 p-3 rounded-lg">{selectedPrescription.notes}</p>
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t">
                <Button className="flex-1">
                  <QrCode className="h-4 w-4 mr-2" />
                  Generate QR Code
                </Button>
                <Button variant="outline" className="flex-1">
                  Download PDF
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
