import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Plus, Search, Edit, Trash2, Eye } from "lucide-react";
import { Badge } from "./ui/badge";

interface Medicine {
  id: string;
  name: string;
  genericName: string;
  category: string;
  dosage: string;
  uses: string;
  sideEffects: string;
  warnings: string;
  manufacturer: string;
}

const mockMedicines: Medicine[] = [
  {
    id: "1",
    name: "Aspirin",
    genericName: "Acetylsalicylic Acid",
    category: "Pain Reliever",
    dosage: "75mg, 100mg, 325mg",
    uses: "Used to reduce pain, fever, and inflammation. Also used to prevent heart attacks and strokes.",
    sideEffects: "Stomach upset, heartburn, nausea, minor bleeding",
    warnings: "Do not use if allergic to NSAIDs. Consult doctor if pregnant.",
    manufacturer: "Bayer Healthcare",
  },
  {
    id: "2",
    name: "Metformin",
    genericName: "Metformin Hydrochloride",
    category: "Antidiabetic",
    dosage: "500mg, 850mg, 1000mg",
    uses: "Used to treat type 2 diabetes. Helps control blood sugar levels.",
    sideEffects: "Nausea, vomiting, stomach upset, diarrhea, weakness, metallic taste",
    warnings: "Not for type 1 diabetes. Risk of lactic acidosis. Monitor kidney function.",
    manufacturer: "Bristol-Myers Squibb",
  },
  {
    id: "3",
    name: "Lisinopril",
    genericName: "Lisinopril",
    category: "ACE Inhibitor",
    dosage: "2.5mg, 5mg, 10mg, 20mg",
    uses: "Treats high blood pressure and heart failure. Improves survival after heart attack.",
    sideEffects: "Dizziness, headache, persistent dry cough, fatigue",
    warnings: "Do not use during pregnancy. Monitor potassium levels. Report swelling.",
    manufacturer: "AstraZeneca",
  },
  {
    id: "4",
    name: "Atorvastatin",
    genericName: "Atorvastatin Calcium",
    category: "Statin",
    dosage: "10mg, 20mg, 40mg, 80mg",
    uses: "Lowers cholesterol and triglycerides. Reduces risk of heart disease and stroke.",
    sideEffects: "Muscle pain, weakness, digestive problems, increased blood sugar",
    warnings: "Avoid grapefruit juice. Monitor liver function. Report muscle pain.",
    manufacturer: "Pfizer",
  },
];

export function MedicineManagement() {
  const [medicines, setMedicines] = useState<Medicine[]>(mockMedicines);
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedMedicine, setSelectedMedicine] = useState<Medicine | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [formData, setFormData] = useState<Partial<Medicine>>({});

  const filteredMedicines = medicines.filter(medicine =>
    medicine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    medicine.genericName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    medicine.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddMedicine = () => {
    const newMedicine: Medicine = {
      id: String(medicines.length + 1),
      name: formData.name || "",
      genericName: formData.genericName || "",
      category: formData.category || "",
      dosage: formData.dosage || "",
      uses: formData.uses || "",
      sideEffects: formData.sideEffects || "",
      warnings: formData.warnings || "",
      manufacturer: formData.manufacturer || "",
    };
    setMedicines([...medicines, newMedicine]);
    setIsAddDialogOpen(false);
    setFormData({});
  };

  const handleDeleteMedicine = (id: string) => {
    setMedicines(medicines.filter(m => m.id !== id));
  };

  const handleViewMedicine = (medicine: Medicine) => {
    setSelectedMedicine(medicine);
    setIsViewDialogOpen(true);
  };

  return (
    <div className="p-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-semibold text-gray-900">Medicine Management</h1>
          <p className="text-gray-500 mt-1">Manage your medicine database</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Medicine
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add New Medicine</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Brand Name</Label>
                  <Input
                    id="name"
                    value={formData.name || ""}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="genericName">Generic Name</Label>
                  <Input
                    id="genericName"
                    value={formData.genericName || ""}
                    onChange={(e) => setFormData({ ...formData, genericName: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    value={formData.category || ""}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="dosage">Available Dosages</Label>
                  <Input
                    id="dosage"
                    placeholder="e.g., 10mg, 20mg, 40mg"
                    value={formData.dosage || ""}
                    onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="manufacturer">Manufacturer</Label>
                <Input
                  id="manufacturer"
                  value={formData.manufacturer || ""}
                  onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="uses">Uses</Label>
                <Textarea
                  id="uses"
                  rows={3}
                  value={formData.uses || ""}
                  onChange={(e) => setFormData({ ...formData, uses: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="sideEffects">Side Effects</Label>
                <Textarea
                  id="sideEffects"
                  rows={3}
                  value={formData.sideEffects || ""}
                  onChange={(e) => setFormData({ ...formData, sideEffects: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="warnings">Warnings</Label>
                <Textarea
                  id="warnings"
                  rows={3}
                  value={formData.warnings || ""}
                  onChange={(e) => setFormData({ ...formData, warnings: e.target.value })}
                />
              </div>
              <Button onClick={handleAddMedicine} className="w-full">Add Medicine</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search medicines..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Brand Name</TableHead>
                <TableHead>Generic Name</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Dosage</TableHead>
                <TableHead>Manufacturer</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMedicines.map((medicine) => (
                <TableRow key={medicine.id}>
                  <TableCell className="font-medium">{medicine.name}</TableCell>
                  <TableCell>{medicine.genericName}</TableCell>
                  <TableCell>
                    <Badge variant="secondary">{medicine.category}</Badge>
                  </TableCell>
                  <TableCell className="text-sm">{medicine.dosage}</TableCell>
                  <TableCell className="text-sm">{medicine.manufacturer}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleViewMedicine(medicine)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteMedicine(medicine.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* View Medicine Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Medicine Details</DialogTitle>
          </DialogHeader>
          {selectedMedicine && (
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">Brand Name</Label>
                  <p className="font-medium mt-1">{selectedMedicine.name}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Generic Name</Label>
                  <p className="font-medium mt-1">{selectedMedicine.genericName}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-gray-500">Category</Label>
                  <p className="font-medium mt-1">{selectedMedicine.category}</p>
                </div>
                <div>
                  <Label className="text-gray-500">Available Dosages</Label>
                  <p className="font-medium mt-1">{selectedMedicine.dosage}</p>
                </div>
              </div>
              <div>
                <Label className="text-gray-500">Manufacturer</Label>
                <p className="font-medium mt-1">{selectedMedicine.manufacturer}</p>
              </div>
              <div>
                <Label className="text-gray-500">Uses</Label>
                <p className="mt-1 text-sm">{selectedMedicine.uses}</p>
              </div>
              <div>
                <Label className="text-gray-500">Side Effects</Label>
                <p className="mt-1 text-sm">{selectedMedicine.sideEffects}</p>
              </div>
              <div>
                <Label className="text-gray-500">Warnings</Label>
                <p className="mt-1 text-sm text-red-600">{selectedMedicine.warnings}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
