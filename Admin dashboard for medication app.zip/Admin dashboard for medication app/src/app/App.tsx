import { useState, useEffect } from "react";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { MedicineManagement } from "./components/MedicineManagement";
import { UserManagement } from "./components/UserManagement";
import { PrescriptionManagement } from "./components/PrescriptionManagement";
import { AlarmManagement } from "./components/AlarmManagement";
import { Analytics } from "./components/Analytics";
import { getPatients } from "./lib/api";

export type Page =
  | "dashboard"
  | "medicines"
  | "users"
  | "prescriptions"
  | "alarms"
  | "analytics";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");
  const [patients, setPatients] = useState<any[]>([]);

  useEffect(() => {
    getPatients()
      .then((data) => {
        setPatients(data);
      })
      .catch((error) => {
        console.error("Error fetching patients:", error);
      });
  }, []);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />

      <main className="flex-1 overflow-y-auto">
        {currentPage === "dashboard" && <Dashboard />}
        {currentPage === "medicines" && <MedicineManagement />}
        {currentPage === "users" && <UserManagement patients={patients} />}
        {currentPage === "prescriptions" && <PrescriptionManagement />}
        {currentPage === "alarms" && <AlarmManagement />}
        {currentPage === "analytics" && <Analytics />}
      </main>
    </div>
  );
}