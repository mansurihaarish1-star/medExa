const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "haarish@054141",
  database: "medexa_db",
  port: 3306
});

db.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("MySQL Connected");
  }
});

app.get("/", (req, res) => {
  res.send("Server is working");
});

app.get("/patients", (req, res) => {
  console.log("Patients API called");

  db.query("SELECT * FROM patients", (err, result) => {

    if (err) {
      console.log("Query Error:", err);
      res.send(err);
      return;
    }

    console.log("Query Result:", result);
    res.json(result);
  });
});
app.use(express.json());
app.post("/patients", (req, res) => {
  console.log("Received data:", req.body);

  const { name, age, gender, phone, email } = req.body;

  db.query(
    "INSERT INTO patients (name, age, gender, phone, email) VALUES (?, ?, ?, ?, ?)",
    [name, age, gender, phone, email],
    (err, result) => {
      if (err) {
        console.log("Insert error:", err);
        res.status(500).send(err);
      } else {
        res.json({ id: result.insertId });
      }
    }
  );
});
app.delete("/patients/:id", (req, res) => {
  const { id } = req.params;

  db.query("DELETE FROM patients WHERE id = ?", [id], (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).send(err);
    } else {
      res.json({ message: "Patient deleted" });
    }
  });
});

app.listen(5000, () => {
  console.log("Server running on port 5000");
});